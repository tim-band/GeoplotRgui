sudo -Hu wwwrunner Rscript -e "remotes::install_github(repo=c('pvermees/GeoplotR','pvermees/GeoplotRgui'),force=TRUE,lib='~/R')"
/usr/local/sbin/geoplotrctl restart
